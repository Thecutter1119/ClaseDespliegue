# Backend (Express)

Esta carpeta contiene un servidor Express mínimo para el proyecto "Restaurante Clase".

Rutas:
- GET / -> Devuelve un JSON de estado.

Cómo usar:

1. Instalar dependencias:

   npm install

2. Iniciar el servidor:

   npm start

El servidor corre por defecto en el puerto 3000. Puedes cambiarlo con la variable de entorno PORT.
